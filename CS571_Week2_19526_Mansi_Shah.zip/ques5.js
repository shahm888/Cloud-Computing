var http = require('http');
var url = require('url');
var fs = require('fs');
var _ = require('underscore');

const fileContent = fs.readFileSync('student_info.json', 'utf8');
const data = JSON.parse(fileContent);

var server = http.createServer(function (req, res) {
    const parsedURL = url.parse(req.url, true);
    const qData = parsedURL.query;

    if (/^\/api\/score/.test(req.url)) {
        var stu_id = qData.student_id;
        if (stu_id) {
            var search_obj = {};
            search_obj["student_id"] = Number(stu_id);
            var result = _.where(data, search_obj);
            if (_.isEmpty(result)) {

                res.writeHead(404, {'Content-Type': 'text/plain'});
                res.end("Student not found.");
            } else {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify(result));
            }
        } else {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(data));
        }
    } else {
        res.writeHead(404);
        res.end();
    }
})

server.listen(8080);